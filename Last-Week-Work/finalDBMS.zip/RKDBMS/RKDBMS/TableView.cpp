// TableView.cpp : implementation file
//

#include "stdafx.h"
#include "RKDBMS.h"
#include "TableView.h"

#include "Global.h"
#include "RKDBMSDoc.h"


// CTableView

IMPLEMENT_DYNCREATE(CTableView, CListView)

CTableView::CTableView()
{
	m_pListCtrl = NULL;
}

CTableView::~CTableView()
{
}

BEGIN_MESSAGE_MAP(CTableView, CListView)
	ON_NOTIFY_REFLECT(NM_RCLICK, &CTableView::OnNMRClick)
END_MESSAGE_MAP()


// CTableView diagnostics

#ifdef _DEBUG
void CTableView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CTableView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif
#endif //_DEBUG


// CTableView message handlers

/***********************************************
[FunctionName]	OnInitialUpdate
[Function]	View initialization function, initialize tree view
[Argument]	void
[ReturnedValue]	void
***********************************************/
void CTableView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	// Get list control
	m_pListCtrl = &this->GetListCtrl();
	
	// Get the default style of list control
	DWORD dwStyle = ::GetWindowLong(m_pListCtrl->m_hWnd ,GWL_STYLE);

	// Set the style of the list control
	dwStyle |= LVS_REPORT;	// Report style
	::SetWindowLong (m_pListCtrl->m_hWnd ,GWL_STYLE, dwStyle);
	
	// Set extended style
	m_pListCtrl->SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	// Initialize the column of the list control
	m_pListCtrl->InsertColumn(0, _T("Column"), LVCFMT_CENTER, 100);
	m_pListCtrl->InsertColumn(1, _T("Data Type"), LVCFMT_CENTER, 100);
	m_pListCtrl->InsertColumn(2, _T("Not NULL"), LVCFMT_CENTER, 200);
	m_pListCtrl->InsertColumn(3, _T("Primary Key"), LVCFMT_CENTER,100);
	m_pListCtrl->InsertColumn(4, _T("Default Value"), LVCFMT_CENTER,200);
}

/**************************************************************
[FunctionName]	OnUpdate
[Function]	View update function
[Argument]	CView* pSender: Points to the view that modified the document, or NULL if all views are to be updated.
		LPARAM lHint: Contains information about the modifications.
		CObject* pHint: Points to an object storing information about the modifications.
[ReturnedValue]	void
**************************************************************/
void CTableView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint)
{
	if(pSender == NULL)
	{
		// Get the object of the document
		CRKDBMSDoc* pDoc = (CRKDBMSDoc*)this->GetDocument();
		switch(lHint)
		{
		case UPDATE_CREATE_TABLE:
			{
				m_pTable = (CTableEntity*)pHint;
			}
			break;
		case UPDATE_EDIT_TABLE:
			{
				m_pTable = (CTableEntity*)pHint;

				int nFieldNum = m_pTable->GetFieldNum();
				for (int i = 0; i < nFieldNum; i++)
				{
					AddField(m_pTable->GetFieldAt(i));
				}
			}
			break;
		case UPDATE_ADD_FIELD:
			{
				if(m_pTable == pDoc->GetEditTable())
				{
					CFieldEntity* pField = (CFieldEntity*)pHint;
					AddField(pField);
				}
			}
			break;
		default:
			break;
		}
	}
}



/**************************************************************
[FunctionName]	AddField
[Function]	Display the field information int the list
[Argument]	CFieldEntity* pField: Pointer to the entity object of field information
[ReturnedValue]	void
**************************************************************/
void CTableView::AddField(CFieldEntity* pField)
{
	// Get the number of the row int the list
	int nCount = m_pListCtrl->GetItemCount();

	// Insert data into the list
	m_pListCtrl->InsertItem(nCount, pField->GetName());	// Field name
	
	int nDataType = pField->GetDataType();				// Type
	CString nTypeName = pField->GetTypeName(nDataType);
	m_pListCtrl->SetItemText(nCount, 1, nTypeName);

}

/**************************************************************
[FunctionName]	OnNMRClick
[Function]	NM_RCLICK message response function of list control��display the right-click menu
[Argument]	NMHDR *pNMHDR: Include the data of the selected item
[ReturnedValue]	void
**************************************************************/
void CTableView::OnNMRClick(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	// Convert NMHDR* type into NM_LISTVIEW* type
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// Get the row number and column number of the selected item
	DWORD dwRow = pNMListView->iItem;  // The selected row
	int nCol = pNMListView->iSubItem;  // The selected column

	// Get the cursor coordinates
	CPoint point;
	GetCursorPos(&point);

	// Load field menu resource to the CMenu object
	CMenu* pMenu = this->GetParentFrame()->GetMenu()->GetSubMenu(MENU_FIELD);

	// Display the menu in the position of the cursor clicked
	pMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, AfxGetMainWnd());

	*pResult = 0;
}
